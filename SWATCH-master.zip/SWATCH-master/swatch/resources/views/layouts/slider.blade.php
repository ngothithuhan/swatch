 <div id="fwslider">
        <div class="slider_container">
            <div class="slide"> 
                <!-- Slide image -->
                    <img src="{{URL::asset('page/images/banner.jpg')}}" alt=""/>
            </div>
            <!-- /Duplicate to create more slides -->
             <div class="slide">
                <img src="{{URL::asset('page/images/banner2.jpg')}}" alt=""/>
            </div>
            <!--/slide -->
        </div>
        <div class="timers"></div>
        <div class="slidePrev"><span></span></div>
        <div class="slideNext"><span></span></div>
    </div>