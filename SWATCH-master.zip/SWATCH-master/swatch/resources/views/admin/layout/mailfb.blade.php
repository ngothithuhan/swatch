<!DOCTYPE html>

<html>

<head>

	<title>Phản hồi khách hàng</title>

</head>

<body>

	<h3>Email từ SWatch.com</h3>

	<p>Cảm ơn {{ $data['name'] }} đã gửi email về trung tâm chăm sóc khách hàng của SWatch.com!</p>
	<p>{{$data['content']}}</p>

</body>

</html>