<?php  
namespace App\Repositories\Comment;
interface CommentRepositoryInterface{
	public function getById($id);
}
?>
