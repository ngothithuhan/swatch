<?php  
namespace App\Repositories\OrderDetail;
interface OrderDetailRepositoryInterface{

}
?>
