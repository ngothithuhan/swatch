<?php  
namespace App\Repositories\Customer;
interface CustomerRepositoryInterface{

}
?>
