<?php  
namespace App\Repositories\Sale;
interface SaleRepositoryInterface{
	public function getSale();
}
?>
