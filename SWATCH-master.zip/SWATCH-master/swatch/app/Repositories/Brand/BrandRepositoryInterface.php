<?php  
namespace App\Repositories\Brand;
interface BrandRepositoryInterface{
	public function getBySlug($slug);
	
}
?>
