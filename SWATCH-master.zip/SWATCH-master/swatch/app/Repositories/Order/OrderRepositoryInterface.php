<?php  
namespace App\Repositories\Order;
interface OrderRepositoryInterface{
	public function getById($id);
}
?>
