<?php  
namespace App\Repositories\Category;
interface CategoryRepositoryInterface{

}
?>
